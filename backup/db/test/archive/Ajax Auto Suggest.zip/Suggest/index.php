//  scriptime.blogspot.in

<HTML>
 <HEAD>
  <TITLE> Ajax php Auto Suggest </TITLE>
  
  <link href="css/style.css" rel="stylesheet" type="text/css">
  
 <SCRIPT LANGUAGE="JavaScript" src="js/jquery.js"></SCRIPT>
 <SCRIPT LANGUAGE="JavaScript" src="js/script.js"></SCRIPT>
 </HEAD>
 <BODY>
 <center>

   <div class="main">
      <div class=""><a href="http://www.scriptime.blogspot.in">scriptime</a></span></div>
     	 <div id="holder"> 
		 Enter Keyword : <input type="text" id="keyword" tabindex="0"><img src="images/loading.gif" id="loading">
		 </div>
		 <div id="ajax_response"></div>
	 
   </div>
 </center>
 </BODY>
</HTML>